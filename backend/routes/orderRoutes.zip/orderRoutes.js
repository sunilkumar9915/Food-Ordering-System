const express = require("express");
const router = express.Router();

const {
    placeOrder,
    getUserOrders,
    getAllOrders,
    updateOrderStatus,
    cancelOrder
} = require("../controllers/orderController");

// ==========================
// USER ROUTES
// ==========================

// Place Order
router.post("/", placeOrder);

// Get My Orders
router.get("/", getUserOrders);

// Cancel Order
router.put("/cancel/:id", cancelOrder);

// ==========================
// ADMIN ROUTES
// ==========================

// Get All Orders
router.get("/all", getAllOrders);

// Update Order Status
router.put("/status/:id", updateOrderStatus);

module.exports = router;