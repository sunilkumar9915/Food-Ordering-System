// ==========================
// TOTAL AMOUNT
// ==========================

const total = localStorage.getItem("totalAmount") || 0;

document.getElementById("totalAmount").innerHTML = "₹" + total;

// ==========================
// PAY NOW
// ==========================


async function payNow() {

    const method = document.querySelector('input[name="payment"]:checked').value;

    const button = document.querySelector("button");

    button.innerHTML = "⏳ Processing Payment...";
    button.disabled = true;

    // Demo Delay
    setTimeout(async() => {

        const customerName = localStorage.getItem("customerName");
        const phone = localStorage.getItem("customerPhone");
        const address = localStorage.getItem("customerAddress");

        const items = JSON.parse(localStorage.getItem("cartData")) || [];

        const user = JSON.parse(localStorage.getItem("user"));



        const orderData = {

            userId: user._id,

            customerName,
            phone,
            address,

            items: cart,

            totalAmount: total

        };

        try {

            const res = await fetch("http://localhost:5000/api/orders", {

                method: "POST",

                headers: {

                    "Content-Type": "application/json"

                },

                body: JSON.stringify(orderData)

            });

            const data = await res.json();

            if (data.success) {

                alert("✅ Payment Successful\n\nMethod : " + method);

                // Clear Local Storage
                localStorage.removeItem("cart");
                localStorage.removeItem("cartData");
                localStorage.removeItem("customerName");
                localStorage.removeItem("customerPhone");
                localStorage.removeItem("customerAddress");
                localStorage.removeItem("totalAmount");

                // Orders Page
                window.location.href = "orders.html";

            } else {

                alert(data.message);

                button.innerHTML = "💳 Pay Now";
                button.disabled = false;

            }

        } catch (error) {

            alert("Server Error");

            button.innerHTML = "💳 Pay Now";
            button.disabled = false;

        }

    }, 2000);

}